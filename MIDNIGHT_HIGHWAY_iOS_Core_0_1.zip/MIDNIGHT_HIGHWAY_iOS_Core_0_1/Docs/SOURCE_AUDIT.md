# Source audit — user-provided archives

## Bayshore_legacy (branch master_6)
- The archive identifies itself as a WMMT6 server implementation written in TypeScript.
- `src/modules/cars.ts` implements server endpoints for loading, creating, and updating a car; it depends on Express, protobuf messages, Prisma, and a database.
- `src/modules/game/story.ts` records story-result fields such as play/clear counts, consecutive wins, tuning points, completion count, and clear bits.
- `src/modules/game/time_attack.ts` stores course/time/section split/tuning data and filters implausible times.
- `prisma/schema.prisma` contains car, tuning, story-related state, and time-attack record models.
- The archive's `package.json` says MIT, while the root `LICENSE` file is GNU AGPLv3. This mismatch must be resolved against the upstream project's intended licensing before redistributing modified server code. Do not assume the package.json field overrides the LICENSE file.
- This server does not contain the 3D renderer, road assets, vehicle models, or a self-contained playable game client.

## WanganArcadeLoader0.5
- Rust `cdylib` loader/hook project, not a game client.
- Uses GLFW, X11, SDL2, OpenGL function loading, dynamic symbol hooks, and Linux-oriented native interfaces.
- `src/jamma.rs` maps physical arcade inputs (steering, accelerator, brake, gear bits) into the target process's memory/interface.
- The build/runtime assumptions are incompatible with a direct iOS build. Its low-level process hooks and X11 window assumptions need a new iOS-native input/rendering implementation, not a simple rename or repackaging.
- Root LICENSE is GPLv3.

## iOS project direction
Build a clean, original, offline-first iOS game. Reuse only high-level product ideas (garage, tuning, story progression, time attack, steering/throttle/brake/gear controls). Do not copy game assets, executable code, proprietary game data, branding, or music. The Swift package in this archive is a newly written domain-model foundation, not a playable game yet.
