# MIDNIGHT HIGHWAY — iOS Core 0.1

This is the first independently written Swift foundation for an original, single-player iPhone highway racer.

## Included
- Local career save model
- Car garage and 0–17 power/handling tuning values
- Story episode progress (default 100 episodes)
- Time-attack records and best-time sorting
- Automatic/manual transmission setting
- Normalized steering, throttle, and brake input model
- Audit of the two user-supplied source archives

## Not included yet
- 3D renderer, road, traffic, vehicle physics, sound, UI, touch controls, gyro integration, or installable IPA
- No original WMMT executable, ROM, copyrighted assets, or online multiplayer/server mode

## Build limitation
This Swift package requires an Apple build environment (Xcode on a Mac, or another supported Apple development workflow). An iPhone 13 alone cannot compile/sign a native iOS app from this ZIP. The source can be reviewed on iPhone, but installation as an app is not yet possible from this package.

## Suggested next implementation order
1. SceneKit/Metal rendering prototype and original highway scene.
2. Vehicle handling model with acceleration, braking, steering, gears, and speed display.
3. Touch steering + throttle/brake; then Core Motion gyro steering as an optional mode.
4. Garage, tuning UI, story progression, and local save integration.
5. iPhone 13 performance and thermal testing in an actual signed build.
