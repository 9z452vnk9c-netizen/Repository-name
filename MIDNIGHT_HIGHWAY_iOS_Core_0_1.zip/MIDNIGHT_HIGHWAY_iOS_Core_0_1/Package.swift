// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "MidnightHighwayCore",
    platforms: [.iOS(.v16)],
    products: [.library(name: "MidnightHighwayCore", targets: ["MidnightHighwayCore"])],
    targets: [.target(name: "MidnightHighwayCore")]
)
