import Foundation

/// Original, offline-first game-domain models. No network service is required.
public enum Transmission: String, Codable, CaseIterable { case automatic, manual }

public struct CarSpec: Codable, Identifiable, Equatable {
    public let id: UUID
    public var displayName: String
    public var powerLevel: Int
    public var handlingLevel: Int
    public var mileageKM: Int

    public init(id: UUID = UUID(), displayName: String, powerLevel: Int = 0,
                handlingLevel: Int = 0, mileageKM: Int = 0) {
        self.id = id
        self.displayName = displayName
        self.powerLevel = min(17, max(0, powerLevel))
        self.handlingLevel = min(17, max(0, handlingLevel))
        self.mileageKM = max(0, mileageKM)
    }

    public var totalTunePoints: Int { powerLevel + handlingLevel }

    public mutating func setTuning(power: Int, handling: Int) {
        powerLevel = min(17, max(0, power))
        handlingLevel = min(17, max(0, handling))
    }
}

public struct StoryProgress: Codable, Equatable {
    public private(set) var clearedEpisodes: Set<Int> = []
    public private(set) var currentEpisode: Int = 1
    public let episodeCount: Int

    public init(episodeCount: Int = 100) {
        self.episodeCount = max(1, episodeCount)
    }

    public mutating func recordClear(episode: Int) {
        guard (1...episodeCount).contains(episode) else { return }
        clearedEpisodes.insert(episode)
        currentEpisode = min(episodeCount, max(currentEpisode, episode + 1))
    }

    public var completion: Double {
        Double(clearedEpisodes.count) / Double(episodeCount)
    }
}

public struct TimeAttackRecord: Codable, Identifiable, Equatable {
    public let id: UUID
    public let courseID: String
    public let elapsedMilliseconds: Int
    public let achievedAt: Date
    public let carName: String

    public init(id: UUID = UUID(), courseID: String, elapsedMilliseconds: Int,
                achievedAt: Date = Date(), carName: String) {
        self.id = id
        self.courseID = courseID
        self.elapsedMilliseconds = max(0, elapsedMilliseconds)
        self.achievedAt = achievedAt
        self.carName = carName
    }
}

/// Normalized steering/throttle/brake values: -1...1 and 0...1 respectively.
public struct DriveInput: Equatable {
    public var steering: Double
    public var throttle: Double
    public var brake: Double

    public init(steering: Double = 0, throttle: Double = 0, brake: Double = 0) {
        self.steering = min(1, max(-1, steering))
        self.throttle = min(1, max(0, throttle))
        self.brake = min(1, max(0, brake))
    }
}

/// Local save container; callers can encode/decode this with JSONEncoder.
public struct LocalCareer: Codable, Equatable {
    public var cars: [CarSpec]
    public var story: StoryProgress
    public var timeAttackRecords: [TimeAttackRecord]
    public var transmission: Transmission

    public init(cars: [CarSpec] = [], story: StoryProgress = StoryProgress(),
                timeAttackRecords: [TimeAttackRecord] = [],
                transmission: Transmission = .automatic) {
        self.cars = cars
        self.story = story
        self.timeAttackRecords = timeAttackRecords
        self.transmission = transmission
    }

    public mutating func addTimeAttackRecord(_ record: TimeAttackRecord) {
        timeAttackRecords.append(record)
        timeAttackRecords.sort { $0.elapsedMilliseconds < $1.elapsedMilliseconds }
    }
}
